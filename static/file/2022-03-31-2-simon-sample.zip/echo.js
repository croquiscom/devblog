const http = require('http');
const server = http.createServer((req, res) => {
  req.pipe(res);
});
server.listen(3000);
